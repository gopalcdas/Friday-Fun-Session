﻿using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Net;

public static class GoogleApiUtils
{
    public static List<string> GetListOfEmailIds(JObject emailListJobject)
    {
        List<string> listOfMailIds = new List<string>();

        long numberOfEmails = GetNumberOfEmails(emailListJobject);

        for (int i = 0; i < numberOfEmails; i++)
        {
            string id = GetEmailId(emailListJobject, i);
            listOfMailIds.Add(id);
        }

        return listOfMailIds;
    }

    public static string GetEmailMessageRaw(JObject readEmailRawJobject)
    {
        JToken raw = readEmailRawJobject[GoogleApiConstants.GMAIL_MESSAGE_RAW];
        return (string)((JValue)raw).Value;
    }

    public static MailInfo GetSubjectBodyAndLabel(JObject readEmailFullJobject)
    {
        MailInfo mailInfo = new MailInfo();

        mailInfo.SubjectAndBody.Add(GetSubject(readEmailFullJobject));

        // we can find body parts
        //JToken payload = readEmailFullJobject[GoogleApiConstants.GMAIL_MESSAGE_PAYLOAD];
        //JToken parts = (JArray)payload["parts"]; // got to check

        //foreach (var item in parts.Children())
        //{
        //    var body = item["body"];
        //    string bodyData = (string)((JValue)((JProperty)body.Last).Value).Value;

        //    var decodedBodyData = StringUtils.Base64UrlDecode(bodyData);
        //    // decoded plain text of raw
        //    var decodedBodyDataPlainText = Encoding.UTF8.GetString(decodedBodyData);

        //    subjectAndBody.Add(decodedBodyDataPlainText);
        //}

        mailInfo.Labels = GetLabels(readEmailFullJobject);

        return mailInfo;
    }

    private static List<string> GetLabels(JObject readEmailFullJobject)
    {
        List<string> labels = new List<string>();

        JToken labelsIds = readEmailFullJobject[GoogleApiConstants.GMAIL_MESSAGE_LABELIDS];
 
        foreach (var item in labelsIds.Children())
            labels.Add((string)((JValue)item).Value);

        return labels;
    }

    public static HttpWebRequest CreateHttpWebRequest(string requestUriString, string method, string contentType, 
        string accessToken)
    {
        HttpWebRequest tokenRequest = (HttpWebRequest)WebRequest.Create(requestUriString);
        tokenRequest.Method = method;
        if(accessToken.Length > 0)
            tokenRequest.Headers.Add(string.Format(GoogleApiConstants.HTTP_HEADER_AUTHORIZATION_BEARER, accessToken));
        tokenRequest.ContentType = contentType;
        tokenRequest.Accept = CommunicationConstants.HTTP_HEADER_ACCEPT;

        return tokenRequest;
    }

    private static long GetNumberOfEmails(JObject emailListJobject)
    {
        //JToken jSize = emailListJobject[GoogleApiConstants.GMAIL_MESSAGE_LIST_SIZE];
        //return (long)((JValue)jSize).Value;

        return ((JArray)((JContainer)emailListJobject.First).First).Count;
    }

    private static string GetEmailId(JObject emailListJobject, int index)
    {
        return (string)((JValue)(((JProperty)emailListJobject.First).Value[index].First.First)).Value;
    }

    private static string GetSubject(JObject readEmailFullJobject)
    {
        JToken payload = readEmailFullJobject[GoogleApiConstants.GMAIL_MESSAGE_PAYLOAD];
        JToken headers = (JArray)payload[GoogleApiConstants.GMAIL_MESSAGE_HEADERS];

        foreach (var item in headers.Children())
        {
            var key = ((JValue)(((JProperty)item.First).Value)).Value;
            if (((string)key).Equals(GoogleApiConstants.GMAIL_MESSAGE_SUBJECT))
                return (string)((JValue)(((JProperty)item.Last).Value)).Value;
        }

        return string.Empty;
    }

    //private static DateTime GetDateFromMail(JObject readEmailRawJobject)
    //{
    //    JToken internalDate = readEmailRawJobject[GoogleApiConstants.GMAIL_MESSAGE_INTERNAL_DATE];
    //    return Utils.FromUnixTime(Convert.ToInt64(((JValue)internalDate).Value));
    //}
}