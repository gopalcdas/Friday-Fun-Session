﻿using System.Collections.Generic;

public class MailInfo
{
    public List<string> SubjectAndBody;
    public List<string> Labels;

    public MailInfo() {
        SubjectAndBody = new List<string>();
        Labels = new List<string>();
    }
}