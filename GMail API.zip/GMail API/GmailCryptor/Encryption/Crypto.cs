﻿using System;
using System.Text;
using System.Security.Cryptography;
using System.IO;

public static class Crypto
{
    public static string EncryptRijndael(string text, string inputKey, string salt)
    {
        if (string.IsNullOrEmpty(text))
        {
            Io.Output("Empty plain text.");
            return string.Empty;
        }

        var aesAlg = NewRijndaelManaged(inputKey, salt);

        var encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);
        var msEncrypt = new MemoryStream();
        using (var csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
        using (var swEncrypt = new StreamWriter(csEncrypt))
        {
            swEncrypt.Write(text);
        }

        return Convert.ToBase64String(msEncrypt.ToArray());
    }

    public static string DecryptRijndael(string cipherText, string inputKey, string salt)
    {
        if (string.IsNullOrEmpty(cipherText))
        {
            Io.Output("Empty cipherText");
            return string.Empty;
        }

        if (!StringUtils.IsBase64String(cipherText))
        {
            Io.Output("The cipherText input parameter is not base64 encoded");
            return string.Empty;
        }

        string text;

        var aesAlg = NewRijndaelManaged(inputKey, salt);
        var decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);
        var cipher = Convert.FromBase64String(cipherText);

        using (var msDecrypt = new MemoryStream(cipher))
        {
            using (var csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
            {
                using (var srDecrypt = new StreamReader(csDecrypt))
                {
                    text = srDecrypt.ReadToEnd();
                }
            }
        }

        return text;
    }

    private static RijndaelManaged NewRijndaelManaged(string inputkey, string salt)
    {
        if (salt == null) throw new ArgumentNullException("salt");
        var saltBytes = Encoding.ASCII.GetBytes(salt);
        var key = new Rfc2898DeriveBytes(inputkey, saltBytes);

        var aesAlg = new RijndaelManaged();
        aesAlg.Key = key.GetBytes(aesAlg.KeySize / 8);
        aesAlg.IV = key.GetBytes(aesAlg.BlockSize / 8);

        return aesAlg;
    }

    public static byte[] Sha256(string inputStirng)
    {
        byte[] bytes = Encoding.ASCII.GetBytes(inputStirng);
        SHA256Managed sha256 = new SHA256Managed();
        return sha256.ComputeHash(bytes);
    }

    public static string RandomDataBase64url(uint length)
    {
        RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
        byte[] bytes = new byte[length];
        rng.GetBytes(bytes);
        return StringUtils.Base64UrlEncodeNoPadding(bytes);
    }
}