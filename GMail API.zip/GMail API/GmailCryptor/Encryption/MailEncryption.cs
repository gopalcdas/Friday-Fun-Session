﻿using System.Collections.Generic;
using System.Text;

public static class MessageEncryption
{
    // we can some how mark this raw as an encrypted one, if required, say to avoid encrypting an already encrypted mail
    public static string GetEncodedEncryptedRawString(string EncodedRawString, MailInfo mailInfo, string inputKey, string salt)
    {
        // decoded raw
        var decodedRaw = StringUtils.Base64UrlDecode(EncodedRawString);

        // decoded plain text of raw
        var decodedRawPlainText = Encoding.UTF8.GetString(decodedRaw);

        // subject and body in raw encrypted decoded text
        var encryptedData = GetSubjectAndBodyEncrypted(decodedRawPlainText, mailInfo.SubjectAndBody, inputKey, salt);
        if (encryptedData.Length == 0)
            return string.Empty;

        // encode the raw
        var encodedBack = StringUtils.Base64UrlEncodeByString(encryptedData);

        return encodedBack;
    }

    // encrypting subject and body (including html body)
    private static string GetSubjectAndBodyEncrypted(string decodedRawPlainText, List<string> subjectAndBody, string inputKey, string salt)
    {
        int index = decodedRawPlainText.IndexOf(GoogleApiConstants.GMAIL_MESSAGE_SUBJECT_IN_RAW + subjectAndBody[0])
                        + GoogleApiConstants.GMAIL_MESSAGE_SUBJECT_IN_RAW.Length;

        if (index == -1)
            return string.Empty;

        var stringToEncrypt = decodedRawPlainText.Substring(index);

        string stringEncrypted = Crypto.EncryptRijndael(stringToEncrypt, inputKey, salt);

        decodedRawPlainText = decodedRawPlainText.Remove(index);
        decodedRawPlainText = decodedRawPlainText + stringEncrypted;

        //foreach (var stringToEncrypt in subjectAndBody)
        //{
        //    index = decodedRawPlainText.IndexOf(stringToEncrypt);
        //    if (index == -1)
        //        return string.Empty;

        //    string stringEncrypted = Crypto.EncryptRijndael(stringToEncrypt, inputKey, salt);

        //    decodedRawPlainText = decodedRawPlainText.Remove(index, stringToEncrypt.Length);
        //    decodedRawPlainText = decodedRawPlainText.Insert(index, stringEncrypted);

        //    index = index + stringEncrypted.Length;
        //}

        return decodedRawPlainText;
    }

    //// this will decrypt the message; as of now not used
    //public static string GetDecodedDecryptedRawString(string EncodedEncryptedRawCipherString, MailInfo mailInfo, string inputKey, string salt)
    //{
    //    // decode the cipher (bytes)
    //    var decodedCipherBytes = StringUtils.Base64UrlDecode(EncodedEncryptedRawCipherString);

    //    // decoded cipher(string)
    //    var decodedCipher = Encoding.UTF8.GetString(decodedCipherBytes);

    //    // decrypt the decoded cipher
    //    var decodedPlainText = GetSubjectAndBodyDecrypted(decodedCipher, mailInfo.SubjectAndBody, inputKey, salt);

    //    return decodedPlainText;
    //}

    //// encrypting subject and body (including html body)
    //private static string GetSubjectAndBodyDecrypted(string decodedRawCipher, List<string> subjectAndBody, string inputKey, string salt)
    //{
    //    int index = decodedRawCipher.IndexOf(GoogleApiConstants.GMAIL_MESSAGE_SUBJECT_IN_RAW + subjectAndBody[0])
    //                    + GoogleApiConstants.GMAIL_MESSAGE_SUBJECT_IN_RAW.Length;

    //    if (index == -1)
    //        return string.Empty;

    //    var stringToDecrypt = decodedRawCipher.Substring(index);

    //    string stringDecrypted = Crypto.DecryptRijndael(stringToDecrypt, inputKey, salt);

    //    decodedRawCipher = decodedRawCipher.Remove(index);
    //    decodedRawCipher = decodedRawCipher + stringDecrypted;

    //    //int index = decodedRawCipher.IndexOf(GoogleApiConstants.GMAIL_MESSAGE_SUBJECT_IN_RAW);

    //    //foreach (var stringToDecrypt in subjectAndBody)
    //    //{
    //    //    index = decodedRawCipher.IndexOf(stringToDecrypt);
    //    //    if (index == -1)
    //    //        return string.Empty;

    //    //    string stringDecrypted = Crypto.DecryptRijndael(stringToDecrypt, inputKey, salt);

    //    //    decodedRawCipher = decodedRawCipher.Remove(index, stringToDecrypt.Length);
    //    //    decodedRawCipher = decodedRawCipher.Insert(index, stringDecrypted);

    //    //    index = index + stringDecrypted.Length;
    //    //}

    //    return decodedRawCipher;
    //}
}