﻿using System;
using System.Net;
using System.Net.Sockets;

public static class Utils
{
    // ref http://stackoverflow.com/a/3978040
    public static int GetRandomUnusedPort()
    {
        var listener = new TcpListener(IPAddress.Loopback, 0);
        listener.Start();
        var port = ((IPEndPoint)listener.LocalEndpoint).Port;
        listener.Stop();

        return port;
    }

    //public static DateTime FromUnixTime(long unixTimeMilliseconds)
    //{
    //    var epoch = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
    //    return epoch.AddMilliseconds(unixTimeMilliseconds);
    //}

    //public static bool IsThisMailSatisfyDateCriteria(DateTime emailDate, DateTime startTime, DateTime endTime)
    //{
    //    return (emailDate >= startTime.ToUniversalTime() && emailDate <= endTime.ToUniversalTime());
    //}
}