﻿public static class CommunicationConstants
{
    public const string HTTP_GET = "GET";
    public const string HTTP_POST = "POST";
    public const string LOOPBACK_URI_FORMAT = "http://{0}:{1}/";

    public const string CODE_CHALLENGE_METHOD = "S256";
    public const int STATE_LENGTH = 32;
    public const int VERIFIER_LENGTH = 32;

    public const string HTTP_RESPONSE_TO_BROWSER_FOR_GOOGLE = "<html><head><meta http-equiv='refresh' content='10;url=https://google.com'></head><body>Please return to the app.</body></html>";

    public const string HTTP_RESPONSE_ERROR = "error";

    public const string HTTP_CONTENT_TYPE_APPLICATION_URLENCODED = "application/x-www-form-urlencoded";
    public const string HTTP_CONTENT_TYPE_APPLICATION_JSON = "application/json";
    public const string HTTP_HEADER_ACCEPT = "Accept=text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
}