﻿public static class GoogleApiConstants
{
    public const string CLIENT_ID = "728217853269-5p5up32nttokcr5ji27466m0p0mas4b8.apps.googleusercontent.com";
    public const string CLIENT_SECRET = "RqTgtdxTRw4lIta2L_8paUNL";

    public const string AUTHORIZATION_REQUEST_FORMAT = "{0}?response_type=code&scope=https://www.googleapis.com/auth/gmail.modify&redirect_uri={1}&client_id={2}&state={3}&codeChallenge={4}&codeChallengeMethod={5}";

    public const string AUTHORIZATION_END_POINT = "https://accounts.google.com/o/oauth2/v2/auth";
    public const string TOKEN_END_POINT = "https://www.googleapis.com/oauth2/v4/token";

    public const string EMAIL_LIST_END_POINT_FORMAT = "https://www.googleapis.com/gmail/v1/users/{0}/messages?q=after:{1} before:{2}";
    public const string EMAIL_READ_END_POINT_FORMAT_FULL = "https://www.googleapis.com/gmail/v1/users/{0}/messages/{1}?format=full";
    public const string EMAIL_READ_END_POINT_FORMAT_RAW = "https://www.googleapis.com/gmail/v1/users/{0}/messages/{1}?format=raw";
    public const string EMAIL_INSERT_END_POINT_FORMAT = "https://www.googleapis.com/gmail/v1/users/{0}/messages";

    public const string TOKEN_REQUEST_BODY_FORMAT = "code={0}&redirect_uri={1}&client_id={2}&codeVerifier={3}&client_secret={4}&scope=&grant_type=authorization_code";
    public const string HTTP_HEADER_AUTHORIZATION_BEARER = "Authorization: Bearer {0}";
    public const string HTTP_RESPONSE_CODE = "code";
    public const string HTTP_RESPONSE_STATE = "state";
    public const string HTTP_ACCESS_TOKEN = "access_token";

    public const string GMAIL_MESSAGE_RAW = "raw";
    public const string GMAIL_MESSAGE_INTERNAL_DATE = "internalDate";
    public const string GMAIL_MESSAGE_LIST_SIZE = "resultSizeEstimate";

    public const string GMAIL_MESSAGE_PAYLOAD = "payload";
    public const string GMAIL_MESSAGE_HEADERS = "headers";
    public const string GMAIL_MESSAGE_LABELIDS = "labelIds";

    public const string GMAIL_MESSAGE_SUBJECT = "Subject";

    public const string GMAIL_MESSAGE_SUBJECT_IN_RAW = "Subject: ";
}