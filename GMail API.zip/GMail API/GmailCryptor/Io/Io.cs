﻿using System;
using System.Globalization;
using System.Runtime.InteropServices;

public static class Io
{
    public static bool ReadInput(out string mailbox, out string startDateString, out string endDateString, 
        out string inputKey, out string salt)
    {
        string line;
        int inputCounter = 0;
        mailbox = inputKey = salt = startDateString = endDateString = string.Empty;
        DateTime startTime = DateTime.Today, endTime = DateTime.Today;

        System.IO.StreamReader file =
           new System.IO.StreamReader(InputConstants.INPUT_FILE_PATH);

        while ((line = file.ReadLine()) != null)
        {
            if (line.Trim().Length == 0)
                continue;

            int i = line.IndexOf(" ");
            var key = line.Substring(0, i).ToLower();
            var value = line.Substring(i + 1);

            switch(key)
            {
                case InputConstants.MAIL_BOX:
                    mailbox = value;
                    inputCounter++;
                    break;

                case InputConstants.START_TIME:
                    if (DateTime.TryParseExact(value, InputConstants.APPLICATION_DATE_FORMAT, CultureInfo.InvariantCulture,
                        DateTimeStyles.None, out startTime)) // time inputs are considered local
                    {
                        startDateString = value;
                        inputCounter++;
                    }
                    break;

                case InputConstants.END_TIME:
                    if(DateTime.TryParseExact(value, InputConstants.APPLICATION_DATE_FORMAT, CultureInfo.InvariantCulture,
                        DateTimeStyles.None, out endTime)) // time inputs are considered local
                    {
                        endTime = endTime.AddDays(1);
                        endDateString = endTime.ToString(InputConstants.APPLICATION_DATE_FORMAT);
                        inputCounter++;
                    }
                    break;

                case InputConstants.INPUT_KEY:
                    inputKey = value;
                    inputCounter++;
                    break;

                case InputConstants.SALT:
                    salt = value;
                    inputCounter++;
                    break;

                default:
                    break;
            }
        }

        if (startTime > endTime)
            inputCounter--;

        file.Close();

        return inputCounter == InputConstants.NUMBER_OF_MANDATORY_INPUTS;
    }

    public static void Output(string output)
    {
        Console.WriteLine(output);
    }

    // Hack to bring the Console window to front.
    // ref: http://stackoverflow.com/a/12066376

    [DllImport("kernel32.dll", ExactSpelling = true)]
    public static extern IntPtr GetConsoleWindow();

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool SetForegroundWindow(IntPtr hWnd);

    public static void BringConsoleToFront()
    {
        SetForegroundWindow(GetConsoleWindow());
    }
}