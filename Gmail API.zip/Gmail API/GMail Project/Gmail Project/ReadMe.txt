Please see the details in Report.docx or Report.pdf

Main project is written in VC#. It has to run with elevated privilege.

A simple proof of concept is written in VC++.