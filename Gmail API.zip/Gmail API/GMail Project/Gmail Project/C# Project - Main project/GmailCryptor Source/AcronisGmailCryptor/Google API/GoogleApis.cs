﻿using System;
using System.Net;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.IO;

public static class GoogleApis
{
    public static async Task<string> DoOAuth()
    {
        string acessToken = string.Empty;

        // Generates state and PKCE values.
        string state = Crypto.RandomDataBase64url(CommunicationConstants.STATE_LENGTH);
        string codeVerifier = Crypto.RandomDataBase64url(CommunicationConstants.VERIFIER_LENGTH);
        string codeChallenge = StringUtils.Base64UrlEncodeNoPadding(Crypto.Sha256(codeVerifier));        

        // Creates a redirect URI using an available port on the loopback address.
        string redirectURI = string.Format(CommunicationConstants.LOOPBACK_URI_FORMAT, IPAddress.Loopback, Utils.GetRandomUnusedPort());
        Io.Output("Redirect URI: " + redirectURI);

        // Creates an HttpListener to listen for requests on that redirect URI.
        var http = new HttpListener();
        http.Prefixes.Add(redirectURI);
        Io.Output("Listening..");
        http.Start();

        // Creates the OAuth 2.0 authorization request.
        string authorizationRequest =
            string.Format(GoogleApiConstants.AUTHORIZATION_REQUEST_FORMAT,
            GoogleApiConstants.AUTHORIZATION_END_POINT,
            Uri.EscapeDataString(redirectURI),
            GoogleApiConstants.CLIENT_ID,
            state,
            codeChallenge,
            CommunicationConstants.CODE_CHALLENGE_METHOD);

        // Opens request in the browser.
        System.Diagnostics.Process.Start(authorizationRequest);

        // Waits for the OAuth authorization response.
        var context = await http.GetContextAsync();

        // Brings the Console to Focus.
        Io.BringConsoleToFront();

        // Sends an HTTP response to the browser.
        var response = context.Response;
        var buffer = Encoding.UTF8.GetBytes(CommunicationConstants.HTTP_RESPONSE_TO_BROWSER_FOR_GOOGLE);
        response.ContentLength64 = buffer.Length;
        var responseOutput = response.OutputStream;
        Task responseTask = responseOutput.WriteAsync(buffer, 0, buffer.Length).ContinueWith((task) =>
        {
            responseOutput.Close();
            http.Stop();
            Io.Output("HTTP server stopped.");
        });

        // Checks for errors.
        if (context.Request.QueryString.Get(CommunicationConstants.HTTP_RESPONSE_ERROR) != null)
        {
            Io.Output(String.Format("OAuth authorization error: {0}.", context.Request.QueryString.Get(CommunicationConstants.HTTP_RESPONSE_ERROR)));
            return acessToken;
        }

        if (context.Request.QueryString.Get(GoogleApiConstants.HTTP_RESPONSE_CODE) == null
            || context.Request.QueryString.Get(GoogleApiConstants.HTTP_RESPONSE_STATE) == null)
        {
            Io.Output("Malformed authorization response. " + context.Request.QueryString);
            return acessToken;
        }

        // extracts the code
        var code = context.Request.QueryString.Get(GoogleApiConstants.HTTP_RESPONSE_CODE);
        var incomingState = context.Request.QueryString.Get(GoogleApiConstants.HTTP_RESPONSE_STATE);

        // Compares the receieved state to the expected value, to ensure that
        // this app made the request which resulted in authorization.
        if (incomingState != state)
        {
            Io.Output(String.Format("Received request with invalid state ({0})", incomingState));
            return acessToken;
        }

        Io.Output("Authorization code: " + code);

        // Starts the code exchange at the Token Endpoint.
        return await PerformCodeExchange(code, codeVerifier, redirectURI/*, mailbox, inputKey, salt, startTime, endTime*/);
    }

    private static async Task <string> PerformCodeExchange(string code, string codeVerifier, string redirectURI/*, string mailbox, string inputKey, string salt, DateTime startTime, DateTime endTime*/)
    {
        Io.Output("Exchanging code for tokens...");

        string accessToken = string.Empty;

        // builds the request
        string tokenRequestBody = string.Format(GoogleApiConstants.TOKEN_REQUEST_BODY_FORMAT,
            code,
            Uri.EscapeDataString(redirectURI),
            GoogleApiConstants.CLIENT_ID,
            codeVerifier,
            GoogleApiConstants.CLIENT_SECRET
            );

        // sends the request
        HttpWebRequest tokenRequest = GoogleApiUtils.CreateHttpWebRequest(GoogleApiConstants.TOKEN_END_POINT, 
            CommunicationConstants.HTTP_POST, CommunicationConstants.HTTP_CONTENT_TYPE_APPLICATION_URLENCODED, string.Empty);

        byte[] byteVersion = Encoding.ASCII.GetBytes(tokenRequestBody);
        tokenRequest.ContentLength = byteVersion.Length;
        Stream stream = tokenRequest.GetRequestStream();
        await stream.WriteAsync(byteVersion, 0, byteVersion.Length);
        stream.Close();

        try
        {
            // gets the response
            WebResponse tokenResponse = await tokenRequest.GetResponseAsync();
            using (StreamReader reader = new StreamReader(tokenResponse.GetResponseStream()))
            {
                // reads the response
                string responseText = await reader.ReadToEndAsync();

                // converts to dictionary
                Dictionary<string, string> tokenEndpointDecoded = JsonConvert.DeserializeObject<Dictionary<string, string>>(responseText);

                accessToken = tokenEndpointDecoded[GoogleApiConstants.HTTP_ACCESS_TOKEN];                
            }
        }
        catch (WebException ex)
        {
            if (ex.Status == WebExceptionStatus.ProtocolError)
            {
                var response = ex.Response as HttpWebResponse;
                if (response != null)
                {
                    Io.Output("HTTP: " + response.StatusCode);
                    using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                    {
                        // reads response body
                        //string responseText = await reader.ReadToEndAsync();
                    }
                }
            }
        }

        return accessToken;
    }

    public static async Task<List<string>> GetEmailIdList(string accessToken, string mailbox, string inputKey, string salt, string startTimeString, string endTimeString)
    {
        var emailListEndpoint = string.Format(GoogleApiConstants.EMAIL_LIST_END_POINT_FORMAT, mailbox, startTimeString, endTimeString);

        HttpWebRequest emailListRequest = GoogleApiUtils.CreateHttpWebRequest(emailListEndpoint,
            CommunicationConstants.HTTP_GET, CommunicationConstants.HTTP_CONTENT_TYPE_APPLICATION_URLENCODED, accessToken);

        WebResponse emailListResponse = await emailListRequest.GetResponseAsync();
        using (StreamReader emailListResponseReader = new StreamReader(emailListResponse.GetResponseStream()))
        {
            string emailListResponseText = await emailListResponseReader.ReadToEndAsync();
            return GoogleApiUtils.GetListOfEmailIds(JObject.Parse(emailListResponseText));
        }
    }

    public static async void ReadAndInsertEmail(string id, string accessToken, string mailbox, string inputKey, string salt)
    {
        string emailEndpoint = string.Format(GoogleApiConstants.EMAIL_READ_END_POINT_FORMAT_RAW, mailbox, id);

        HttpWebRequest readEmailRequest = GoogleApiUtils.CreateHttpWebRequest(emailEndpoint,
            CommunicationConstants.HTTP_GET, CommunicationConstants.HTTP_CONTENT_TYPE_APPLICATION_URLENCODED, accessToken);

        WebResponse readEmailResponse = await readEmailRequest.GetResponseAsync();
        using (StreamReader readEmailResponseReader = new StreamReader(readEmailResponse.GetResponseStream()))
        {
            string readEmailResponseText = await readEmailResponseReader.ReadToEndAsync();

            MailInfo mailInfo = await GetSubjectBodyAndLabel(id, accessToken, mailbox);
            InsertEmail(id, readEmailResponseText, mailInfo, accessToken, mailbox, inputKey, salt);
        }
    }

    private static async Task<MailInfo> GetSubjectBodyAndLabel(string id, string accessToken, string mailbox)
    {
        string emailEndpoint = string.Format(GoogleApiConstants.EMAIL_READ_END_POINT_FORMAT_FULL, mailbox, id);

        HttpWebRequest readEmailRequest = GoogleApiUtils.CreateHttpWebRequest(emailEndpoint,
            CommunicationConstants.HTTP_GET, CommunicationConstants.HTTP_CONTENT_TYPE_APPLICATION_URLENCODED, accessToken);

        WebResponse readEmailResponse = await readEmailRequest.GetResponseAsync();
        using (StreamReader readEmailResponseReader = new StreamReader(readEmailResponse.GetResponseStream()))
        {
            string readEmailResponseText = await readEmailResponseReader.ReadToEndAsync();
            return GoogleApiUtils.GetSubjectBodyAndLabel(JObject.Parse(readEmailResponseText));
        }
    }

    private static async void InsertEmail(string id, string readEmailResponseText, MailInfo mailInfo, string accessToken, string mailbox, string inputKey, string salt)
    {
        string insertEmailEndpoint = string.Format(GoogleApiConstants.EMAIL_INSERT_END_POINT_FORMAT, mailbox);

        HttpWebRequest insertEmailRequest = GoogleApiUtils.CreateHttpWebRequest(insertEmailEndpoint,
                CommunicationConstants.HTTP_POST, CommunicationConstants.HTTP_CONTENT_TYPE_APPLICATION_JSON, accessToken);

        string encodedRaw = GoogleApiUtils.GetEmailMessageRaw(JObject.Parse(readEmailResponseText));
        string encodedBack = MessageEncryption.GetEncodedEncryptedRawString(encodedRaw, mailInfo, inputKey, salt);

        if(encodedBack.Length == 0)
        {
            Io.Output("Failed to insert!");
            return;
        }

        ASCIIEncoding encoding = new ASCIIEncoding();
        var rawData = new { raw = encodedBack, labelIds = mailInfo.Labels };
        byte[] messageBytes = encoding.GetBytes(JsonConvert.SerializeObject(rawData));

        insertEmailRequest.ContentLength = messageBytes.Length;
        Stream newStream = insertEmailRequest.GetRequestStream();

        newStream.Write(messageBytes, 0, messageBytes.Length);
        newStream.Close();

        WebResponse readEmailResponse = await insertEmailRequest.GetResponseAsync();
        using (StreamReader readEmailResponseReader = new StreamReader(readEmailResponse.GetResponseStream()))
        {
            Io.Output(String.Format("Making API Call to Gmail Insert, Message Id: {0}  ...DONE", id));
            string insertEmailResponseText = await readEmailResponseReader.ReadToEndAsync();
        }
    }
}