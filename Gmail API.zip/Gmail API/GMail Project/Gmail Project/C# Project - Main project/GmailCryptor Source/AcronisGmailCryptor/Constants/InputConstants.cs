﻿public static class InputConstants
{
    public const string INPUT_FILE_PATH = "input.txt";

    public const string MAIL_BOX = "mailbox";
    public const string START_TIME = "start_time";
    public const string END_TIME = "end_time";
    public const string INPUT_KEY = "input_key";
    public const string SALT = "salt";

    public const string APPLICATION_DATE_FORMAT = "yyyy/M/d";

    public const int NUMBER_OF_MANDATORY_INPUTS = 5;
}