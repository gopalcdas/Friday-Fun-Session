﻿using System;

namespace AcronisGmailCryptor
{
    class Program
    {
        static void Main(string[] args)
        {
            Io.Output("+-----------------------+");
            Io.Output("| Gmail Cryptor |");
            Io.Output("+-----------------------+");
            Io.Output("");

            string mailbox, inputKey, salt, startTimeString, endTimeString;

            if (!Io.ReadInput(out mailbox, out startTimeString, out endTimeString, out inputKey, out salt))
            {
                Io.Output("Invalid input. File input.txt with all valid inputs must be present in the same folder as the executable . . .");
                Console.ReadKey();
                return;
            }

            Io.Output("Press any key to get authorization from Google . . .");
            Console.ReadKey();

            WorkHorse(mailbox, inputKey, salt, startTimeString, endTimeString);

            Console.ReadKey();
        }

        private static async void WorkHorse(string mailbox, string inputKey, string salt, string startTimeString, string endTimeString)
        {
            try
            {
                string accessToken = await GoogleApis.DoOAuth();

                if (accessToken.Length == 0)
                    return;

                var listOfEmailIds = await GoogleApis.GetEmailIdList(accessToken, mailbox, inputKey, salt, startTimeString, endTimeString);

                Io.Output(listOfEmailIds.Count.ToString() + " mails to be inserted.");

                foreach (var id in listOfEmailIds)
                    GoogleApis.ReadAndInsertEmail(id, accessToken, mailbox, inputKey, salt);
            }
            catch (Exception e)
            {
                Io.Output(e.Message + " Please note that you have to execute this program with elevated privilege!");
            }
        }
    }
}